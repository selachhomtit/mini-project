"use client";

import { useState } from "react";
import Link from "next/link";
import { useRouter, usePathname } from "next/navigation";
import { useAppSelector, useAppDispatch } from "@/lib/hooks";
import { logout } from "@/lib/features/auth/authSlice";
import { useGetUnreadCountQuery } from "@/lib/services/notificationService";
import {
  MoreHorizontal,
  X,
  LayoutDashboard,
  FolderKanban,
  CheckSquare,
  Users,
  Bell,
  Settings,
  LogOut,
  Plus,
  RefreshCw,
} from "lucide-react";

const NAV = [
  { label: "Dashboard",    href: "/dashboard",               icon: LayoutDashboard },
  { label: "Projects",     href: "/dashboard/projects",      icon: FolderKanban },
  { label: "My Tasks",     href: "/dashboard/tasks",         icon: CheckSquare },
  { label: "Team",         href: "/dashboard/team",          icon: Users },
  { label: "Notifications",href: "/dashboard/notifications", icon: Bell, badge: true },
  { label: "Settings",     href: "/dashboard/settings",      icon: Settings },
];

interface Props {
  /** Primary CTA label — shown as the green Create button */
  createLabel?: string;
  /** Called when the Create button is tapped */
  onCreate?: () => void;
  /** Icon-only on very small screens */
  showCreate?: boolean;
  /** Refresh handler */
  onRefresh?: () => void;
}

export default function DashboardHeader({
  createLabel = "Create",
  onCreate,
  showCreate = true,
  onRefresh,
}: Props) {
  const dispatch  = useAppDispatch();
  const router    = useRouter();
  const pathname  = usePathname();
  const user      = useAppSelector((s) => s.auth.user);
  const [menuOpen, setMenuOpen] = useState(false);

  const { data: unread } = useGetUnreadCountQuery();
  const unreadCount = unread?.count ?? 0;

  const initials = user?.name
    ?.split(" ")
    .map((n: string) => n[0])
    .join("")
    .toUpperCase()
    .slice(0, 2) ?? "?";

  const handleLogout = () => {
    setMenuOpen(false);
    dispatch(logout());
    router.push("/login");
  };

  return (
    <header className="h-14 sm:h-16 bg-white dark:bg-slate-900 border-b border-[#E8E8EF] dark:border-slate-700 flex items-center justify-between px-3 sm:px-5 gap-2 shrink-0 sticky top-0 z-30">

      {/* ── Logo ── */}
      <Link href="/" className="flex items-center gap-2 shrink-0 group">
        <div className="w-8 h-8 rounded-lg bg-[#059669] flex items-center justify-center shadow-md shadow-[#059669]/30 group-hover:shadow-[#059669]/50 transition-shadow">
          <svg width="14" height="14" viewBox="0 0 14 14" fill="none">
            <rect x="1" y="1" width="4" height="12" rx="1" fill="white"/>
            <rect x="7" y="1" width="6" height="8" rx="1" fill="white" opacity=".8"/>
          </svg>
        </div>
        <span className="font-bold text-[15px] text-[#1E293B] dark:text-white tracking-tight hidden sm:block">
          TaskFlow
        </span>
      </Link>

      {/* ── Actions ── */}
      <div className="flex items-center gap-1.5">

        {/* Refresh (optional) */}
        {onRefresh && (
          <button
            onClick={onRefresh}
            className="w-9 h-9 rounded-lg flex items-center justify-center text-[#64748B] dark:text-slate-400 hover:bg-slate-100 dark:hover:bg-slate-800 transition-colors"
            aria-label="Refresh"
          >
            <RefreshCw size={15} />
          </button>
        )}

        {/* Create button */}
        {showCreate && onCreate && (
          <button
            onClick={onCreate}
            className="flex items-center gap-1.5 h-9 px-3 sm:px-4 rounded-lg bg-[#059669] hover:bg-[#047857] active:bg-[#4a3cc7] text-white text-sm font-bold transition-colors shadow-sm shadow-[#059669]/30"
          >
            <Plus size={15} strokeWidth={2.5} />
            <span className="hidden sm:inline">{createLabel}</span>
          </button>
        )}

        {/* Notifications bell */}
        <Link
          href="/dashboard/notifications"
          className="relative w-9 h-9 rounded-lg flex items-center justify-center text-[#64748B] dark:text-slate-400 hover:bg-slate-100 dark:hover:bg-slate-800 transition-colors"
          aria-label="Notifications"
        >
          <Bell size={17} />
          {unreadCount > 0 && (
            <span className="absolute top-1 right-1 w-4 h-4 rounded-full bg-[#EF4444] text-white text-[9px] font-bold flex items-center justify-center leading-none">
              {unreadCount > 9 ? "9+" : unreadCount}
            </span>
          )}
        </Link>

        {/* ··· Menu */}
        <div className="relative">
          <button
            onClick={() => setMenuOpen((o) => !o)}
            className={`w-9 h-9 rounded-lg flex items-center justify-center transition-colors ${
              menuOpen
                ? "bg-[#059669] text-white"
                : "text-[#64748B] dark:text-slate-400 hover:bg-slate-100 dark:hover:bg-slate-800"
            }`}
            aria-label="More options"
            aria-expanded={menuOpen}
          >
            {menuOpen ? <X size={17} /> : <MoreHorizontal size={18} />}
          </button>

          {menuOpen && (
            <>
              {/* Backdrop */}
              <div className="fixed inset-0 z-40" onClick={() => setMenuOpen(false)} />

              {/* Dropdown */}
              <div className="absolute right-0 top-full mt-2 w-72 bg-white dark:bg-slate-900 rounded-2xl shadow-2xl shadow-black/15 border border-[#E8E8EF] dark:border-slate-700 z-50 overflow-hidden">

                {/* User row */}
                {user && (
                  <div className="flex items-center gap-3 px-4 py-3.5 border-b border-[#F1F5F9] dark:border-slate-800">
                    <div className="w-9 h-9 rounded-full bg-[#059669]/10 flex items-center justify-center text-[#059669] text-sm font-bold shrink-0">
                      {initials}
                    </div>
                    <div className="min-w-0">
                      <p className="text-sm font-semibold text-[#1E293B] dark:text-white truncate">{user.name}</p>
                      <p className="text-xs text-[#94A3B8] truncate">{user.email}</p>
                    </div>
                  </div>
                )}

                {/* Nav links */}
                <nav className="p-2">
                  {NAV.map(({ label, href, icon: Icon, badge }) => {
                    const isActive = pathname === href || (href !== "/dashboard" && pathname?.startsWith(href));
                    const count = badge ? unreadCount : 0;
                    return (
                      <Link
                        key={href}
                        href={href}
                        onClick={() => setMenuOpen(false)}
                        className={`flex items-center gap-3 px-3 py-2.5 rounded-xl text-sm font-medium transition-colors group ${
                          isActive
                            ? "bg-[#ECFDF5] text-[#059669]"
                            : "text-[#64748B] dark:text-slate-300 hover:bg-[#ECFDF5] hover:text-[#059669] dark:hover:bg-[#059669]/10 dark:hover:text-[#059669]"
                        }`}
                      >
                        <Icon
                          size={17}
                          className={`shrink-0 transition-colors ${
                            isActive ? "text-[#059669]" : "text-[#94A3B8] group-hover:text-[#059669]"
                          }`}
                        />
                        <span className="flex-1">{label}</span>
                        {count > 0 && (
                          <span className="bg-[#EF4444] text-white text-[10px] font-bold px-1.5 py-0.5 rounded-full leading-none">
                            {count > 9 ? "9+" : count}
                          </span>
                        )}
                        {isActive && (
                          <span className="w-1.5 h-1.5 rounded-full bg-[#059669] shrink-0" />
                        )}
                      </Link>
                    );
                  })}
                </nav>

                {/* Sign out */}
                <div className="px-2 pb-2 pt-1 border-t border-[#F1F5F9] dark:border-slate-800">
                  <button
                    onClick={handleLogout}
                    className="flex items-center gap-3 w-full px-3 py-2.5 rounded-xl text-sm font-medium text-[#EF4444] hover:bg-red-50 dark:hover:bg-red-950/30 active:bg-red-100 transition-colors"
                  >
                    <LogOut size={16} className="shrink-0" />
                    Sign out
                  </button>
                </div>

              </div>
            </>
          )}
        </div>

      </div>
    </header>
  );
}
